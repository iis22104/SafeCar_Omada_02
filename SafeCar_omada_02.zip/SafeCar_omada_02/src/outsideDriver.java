
public class outsideDriver {
	private String name;
	private String licence;
	private String lName;
	private String plate;
	public outsideDriver(String name, String licence, String lName, String plate) {
		super();
		this.name = name;
		this.licence = licence;
		this.lName = lName;
		this.plate = plate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLicence() {
		return licence;
	}
	public void setLicence(String licence) {
		this.licence = licence;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getPlate() {
		return plate;
	}
	public void setPlate(String plate) {
		this.plate = plate;
	}
	
	
}
